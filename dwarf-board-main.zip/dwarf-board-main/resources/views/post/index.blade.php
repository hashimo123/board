@include('common.header')

        <div id="main_index">
            <div>
                <h2 class="title" style="font-size: 30px;">welcome<span>ようこそ</span></h2>
            </div>
	        <div>

	        </div>
	    </div>
        <!--スライドショー-->
    <aside id="mainimg">
    <div class="slide1">slide1</div>
    <div class="slide2">slide2</div>
    <div class="slide3">slide3</div>
    </aside>
</div>
@include('common.footer')


